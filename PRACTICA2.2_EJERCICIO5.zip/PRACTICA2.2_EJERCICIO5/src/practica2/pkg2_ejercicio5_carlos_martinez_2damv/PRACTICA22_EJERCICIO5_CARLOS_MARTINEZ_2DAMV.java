/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica2.pkg2_ejercicio5_carlos_martinez_2damv;

/**
 *
 * @author PC
 */
public class PRACTICA22_EJERCICIO5_CARLOS_MARTINEZ_2DAMV {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria();

        for (int i = 1; i <= 5; i++) {
            Cliente cliente = new Cliente(cuenta, "Cliente " + i);
            cliente.start();
        }
    }
}
