/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.pkg2_ejercicio5_carlos_martinez_2damv;

import java.util.Random;
/**
 *
 * @author PC
 */

public class Cliente extends Thread {
    private final CuentaBancaria cuenta;
    private final String nombre;
    private final Random random = new Random();

    public Cliente(CuentaBancaria cuenta, String nombre) {
        this.cuenta = cuenta;
        this.nombre = nombre;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 3; i++) {
            int cantidad = 10 + random.nextInt(991); // 10–1000 €
            boolean ingresar = random.nextBoolean();

            if (ingresar) {
                cuenta.ingresar(nombre, cantidad);
            } else {
                cuenta.retirar(nombre, cantidad);
            }

            System.out.println(nombre + " consulta saldo: " + cuenta.consultarSaldo() + "€");

            try {
                Thread.sleep((1 + random.nextInt(3)) * 1000); // 1–3 segundos
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(nombre + " ha terminado sus 3 operaciones.");
    }
}


