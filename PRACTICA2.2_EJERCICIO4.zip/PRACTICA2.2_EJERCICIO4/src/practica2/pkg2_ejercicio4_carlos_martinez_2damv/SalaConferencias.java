/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.pkg2_ejercicio4_carlos_martinez_2damv;

/**
 *
 * @author PC
 */
public class SalaConferencias {

    private final int capacidadMaxima = 5;
    private int ocupacionActual = 0;

    public synchronized boolean intentarEntrar(String nombre) {
        if (ocupacionActual < capacidadMaxima) {
            ocupacionActual++;
            System.out.println(nombre + " ha entrado. Ocupación: " + ocupacionActual);
            return true;
        } else {
            System.out.println(nombre + " no pudo entrar. Sala llena.");
            return false;
        }
    }

    public synchronized void salir(String nombre) {
        try {
            Thread.sleep(1500); // Simula tiempo de salida
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ocupacionActual--;
        System.out.println(nombre + " ha salido. Ocupación: " + ocupacionActual);
        notifyAll(); // Notifica a los que esperan
    }
}


