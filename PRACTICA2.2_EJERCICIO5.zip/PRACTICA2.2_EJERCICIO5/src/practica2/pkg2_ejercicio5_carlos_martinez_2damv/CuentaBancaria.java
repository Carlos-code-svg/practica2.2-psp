/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.pkg2_ejercicio5_carlos_martinez_2damv;

import java.util.concurrent.Semaphore;
/**
 *
 * @author PC
 */
public class CuentaBancaria {
    
    private int saldo = 0;
    private final Semaphore acceso = new Semaphore(2); // Solo 2 clientes simultáneamente

    public void ingresar(String nombre, int cantidad) {
        try {
            acceso.acquire();
            synchronized (this) {
                saldo += cantidad;
                System.out.println(nombre + " ingresó " + cantidad + "€. Saldo actual: " + saldo + "€");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            acceso.release();
        }
    }

    public void retirar(String nombre, int cantidad) {
        try {
            acceso.acquire();
            synchronized (this) {
                if (saldo >= cantidad) {
                    saldo -= cantidad;
                    System.out.println(nombre + " retiró " + cantidad + "€. Saldo actual: " + saldo + "€");
                } else {
                    System.out.println(nombre + " intentó retirar " + cantidad + "€, pero saldo insuficiente (" + saldo + "€)");
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            acceso.release();
        }
    }

    public synchronized int consultarSaldo() {
        return saldo;
    }
}


