/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.pkg2_ejercicio4_carlos_martinez_2damv;

/**
 *
 * @author PC
 */
    class Empleado extends Thread {
    private final SalaConferencias sala;
    private final String nombre;

    public Empleado(SalaConferencias sala, String nombre) {
        this.sala = sala;
        this.nombre = nombre;
    }

    public void run() {
        int intentos = 0;
        boolean dentro = false;

        while (intentos < 3 && !dentro) {
            synchronized (sala) {
                dentro = sala.intentarEntrar(nombre);
            }

            if (!dentro) {
                intentos++;
                try {
                    Thread.sleep(12000); // Espera 12 segundos antes del siguiente intento
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        if (dentro) {
            try {
                Thread.sleep(10000); // Permanencia en la sala
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            synchronized (sala) {
                sala.salir(nombre);
            }
        } else {
            System.out.println(nombre + " se fue tras 3 intentos fallidos.");
        }
    }
}


